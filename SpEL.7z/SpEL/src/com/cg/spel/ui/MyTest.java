package com.cg.spel.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spel.dto.Employee;
import com.cg.spel.dto.PrintEmployeeDetail;

public class MyTest {

	public static void main(String[] args) {
		ApplicationContext app= new ClassPathXmlApplicationContext("spring.xml");
	Employee ee= (Employee) app.getBean("emp");
	PrintEmployeeDetail pemp=(PrintEmployeeDetail) app.getBean("print");
	pemp.getAllDetail();

	}

}
