package com.cg.springdemothree.dao;

import org.springframework.stereotype.Component;

@Component("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public void getDaoDetail() {
		System.out.println("Inside Dao Layer...");
	}

}
