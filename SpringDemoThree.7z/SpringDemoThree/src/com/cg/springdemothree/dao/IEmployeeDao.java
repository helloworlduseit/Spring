package com.cg.springdemothree.dao;

public interface IEmployeeDao {
public void getDaoDetail();
}
