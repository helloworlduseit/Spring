package com.cg.springdemothree.service;

public interface IEmployeeService {
	public void getData();
}
