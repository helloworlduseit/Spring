package com.cg.dto;

public class Employee{

	int age;
	int employeeId;
	String employeeName;
	double salary;
	String businessUnit;
	SBU sbu;
	
	

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public SBU getSbu() {
		return sbu;
	}

	public void setSbu(SBU sbu) {
		this.sbu = sbu;
	}
	

	
	public void getAllEmployeeDetail() {
		System.out.println("Employee Details\n-----------------------------------\n"
				+ "Employee [empAge=" + age + ", employeeId=" + employeeId
				+ ", employeeName=" + employeeName + ", empSalary=" + salary
				+ ", \nSBU Details =" + sbu.getSBUDetails() + "]"); ;
	}

	
}
