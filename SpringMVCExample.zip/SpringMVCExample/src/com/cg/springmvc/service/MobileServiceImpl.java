package com.cg.springmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc.dao.IMobileDao;
import com.cg.springmvc.dto.MobileBean;

@Service("mobileService")
@Transactional
public class MobileServiceImpl implements IMobileService {
	@Autowired
	IMobileDao mobileDao;
	@Override
	public List<MobileBean> showAllMobile() {
		return mobileDao.showAllMobile();
	}

	@Override
	public void deleteMobile(int mobId) {
		mobileDao.deleteMobile(mobId);
	}

	@Override
	public void updateMobile(MobileBean mob) 
	{
		mobileDao.updateMobile(mob);
	}

	@Override
	public List<MobileBean> showMobilebyId(int id){
		// TODO Auto-generated method stub
		return mobileDao.showMobilebyId(id);
	}

}
