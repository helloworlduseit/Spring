package com.cg.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc.dto.MobileBean;
import com.cg.springmvc.service.IMobileService;


@Controller
public class MobileController 
{
	@Autowired
	IMobileService mobileService;
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView allMobileData()
	{
		List<MobileBean> mList=mobileService.showAllMobile();
		return new ModelAndView("mobileShow","temp",mList);
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String mobileDelete(@RequestParam("id") int mobId)
	{
		mobileService.deleteMobile(mobId);
		return "redirect:/showall";
	}
	@RequestMapping(value="update",method=RequestMethod.GET)
	public ModelAndView mobileUpdate(@RequestParam("id") int mobId,@ModelAttribute ("myUpdate")MobileBean mobile)
	{
		List<MobileBean> mList=mobileService.showMobilebyId(mobId);
		return new ModelAndView("updateShow","temp",mList);
	}
	@RequestMapping(value="doUpdate",method=RequestMethod.POST)
	public String update(@ModelAttribute ("myUpdate")MobileBean mobile)
	{
		mobileService.updateMobile(mobile);
		return "redirect:/showall";
	}
}
