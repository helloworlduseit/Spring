package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails 
{/*
				Name                           		    Null?    Type
			----------------------------------------- -------- ----------------

			PURCHASEID                                         NUMBER
			CNAME                                              VARCHAR2(20)
			MAILID                                             VARCHAR2(30)
			PHONENO                                            VARCHAR2(20)
			PURCHASEDATE                                       DATE
			MOBILEID                                           NUMBER*/
	
	private long purchaseId;
	private String custName;
	private String custEmail;
	private long phoneNo; 
	private LocalDate purchaseDate;
	private Long mobileId;
	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PurchaseDetails(long purchaseId, String custName, String custEmail,
			long phoneNo, LocalDate purchaseDate, Long mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.custName = custName;
		this.custEmail = custEmail;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	public long getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(long purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Long getMobileId() {
		return mobileId;
	}
	public void setMobileId(Long mobileId) {
		this.mobileId = mobileId;
	}
	

}
