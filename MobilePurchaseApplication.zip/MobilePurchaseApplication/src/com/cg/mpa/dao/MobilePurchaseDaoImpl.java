package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobiles;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao 
{
	Connection conn;

	@Override
	public List<Mobiles> getAllMobiles() throws MobileException {
		conn=DBUtil.getConnection();
		List<Mobiles> mlist=new ArrayList<>();
		try{
		Statement st=conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
		while(rst.next())
		{
			Mobiles m=new Mobiles();
			m.setMobileId(rst.getLong("mobileid"));
			m.setmName(rst.getString("name"));
			m.setPrice(rst.getDouble("price"));
			m.setQuantity(rst.getInt("quantity"));;
			mlist.add(m);
		}
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in Fetching Mobile list");
		}
		return mlist;
	}
	/*****************getMobile details of selected id*************************/
	@Override
	public Mobiles getMobile(long mid) throws MobileException 
	{
		conn=DBUtil.getConnection();
		Mobiles m=null;
		try 
		{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1, mid);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				m=new Mobiles();
				m.setMobileId(rst.getLong("mobileid"));
				m.setmName(rst.getString("name"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
				
			}
			else
			{
				throw new MobileException("Mobile Not Found");
			}
		} 
		catch (SQLException e) {
			throw new MobileException("Problem in Fetching Mobile list");
		}
		
		return m;
	}

	/*****************generatePurchaseId()*************************/
	private long generatePurchaseId() throws MobileException
	{
		long pid=0;
		conn=DBUtil.getConnection();
		Statement st;
		try 
		{
		st = conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
		rst.next();
		pid=rst.getLong(1);
		}
		catch (SQLException e) 
		{
			throw new MobileException("Problem in Generating Purchase Id "+e.getMessage());
		}
		return pid;
	}
	/*****************insertPurchaseDetails*************************/
	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException 
	{
		conn=DBUtil.getConnection();
		pDetails.setPurchaseId(generatePurchaseId());
		try {
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, pDetails.getPurchaseId());
			pst.setString(2, pDetails.getCustName());
			pst.setString(3, pDetails.getCustEmail());
			pst.setLong(4, pDetails.getPhoneNo());
			pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pst.setLong(6, pDetails.getMobileId());
			pst.executeUpdate();
			
		} catch (SQLException e) {
			throw new MobileException("Problem in inserting Purchase Details"+e.getMessage());
		}
		
		return pDetails.getPurchaseId();
	}

}
