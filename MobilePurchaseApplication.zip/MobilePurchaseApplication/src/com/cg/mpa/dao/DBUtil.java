package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.SQLException;



import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.mpa.exception.MobileException;

public class DBUtil {

	
		private static Connection conn;
		public static Connection getConnection() throws MobileException{
		if(conn==null)
		{
			InitialContext ic;
			try
			{
			ic= new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/jdbc/OracleDS");
			conn = ds.getConnection();
			}
			catch(NamingException e){
				throw new MobileException("Problem in obtaining DataSource"+e.getMessage());
				
			}
			catch(SQLException ee)
			{
				throw new MobileException("Problem in obtaining Connection from DataSource"+ee.getMessage());
			}
			
		}
		return conn;
		}
		
}
