package com.cg.springdemoone.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemoone.dto.Employee;
import com.cg.springdemoone.dto.Shape;

public class MyTest {

	public static void main(String[] args) {
		ApplicationContext app= 
				new ClassPathXmlApplicationContext("spring.xml");
		//Shape sp=(Shape) app.getBean("tran");
		//sp.getShape();
		Employee ee= (Employee) app.getBean("emp");
		ee.getAllDetail();
	}

}
