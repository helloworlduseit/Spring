package Collection;

import java.util.TreeSet;

public class test {

	public static void main(String[] args) {
		EndComparator ecom = new EndComparator();
		TreeSet<Employee> staff= new TreeSet<Employee>(ecom);
		staff.add(new Employee(101,"jyoti"));
		staff.add(new Employee(103,"ooha"));
		staff.add(new Employee(102,"babz"));
		
		System.out.println(staff);
		

	}

}
