package com.cg.springdemotwo.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemotwo.dto.Employee;
import com.cg.springdemotwo.dto.EmployeeDetail;

public class MyTest {

	public static void main(String[] args) 
	{
		ApplicationContext app= new ClassPathXmlApplicationContext("spring.xml");
		Employee e= (Employee) app.getBean("emp");
		e.getAllEmployeeDetail();
		
	
	}

}
