package com.cg.dto;

import java.util.List;

public class SBU {

	int sbuCode;
	String sbuHead;
	String sbuName;
	List<Employee> emp;
	public int getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public List<Employee> getEmp() {
		return emp;
	}
	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}
	
	public void getSBUDetails() {
		System.out.println("SBU Details\n----------------------\n"
				+ "sbuCode=" + sbuCode + ", sbuHead=" + sbuHead
				+ ", sbuName=" + sbuName+"\nEmployee Details:----------------------------"); 
		for(Employee empl : emp)
		{
			empl.getAllEmployeeDetail();
		}
	}
	
	
}
