package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.dao.EmployeeDao;
import com.cg.dto.Employee;
@Component("employeeservice")
public class EmployeeService {
	@Autowired
	EmployeeDao empdao;
	public Employee getEmpDetail(int empId)
	{
		return(empdao.getEmpDetail(empId));
	}
}
